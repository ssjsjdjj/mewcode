"""Prepare a tested initial draft; activate only the exact draft approved by this user."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent
SOURCE = BUNDLE / "skills/chutu-chicun-tiaozheng"
sys.dont_write_bytecode = True
sys.path.insert(0,str(SOURCE / "scripts"))
from user_profile import Store, file_hash, owner_id, read_json, snapshot_digest, write_json
from validate_candidate import validate_snapshot


def payload(folder):
    return {p.relative_to(folder).as_posix():file_hash(p) for p in sorted(Path(folder).rglob('*'))
            if p.is_file() and p.name != 'runtime.json' and '__pycache__' not in p.parts}


def identifier():
    return datetime.now().strftime('%Y%m%d-%H%M%S-%f')


def run(arguments, log, environment=None):
    result = subprocess.run([str(a) for a in arguments],capture_output=True,encoding='utf-8',errors='replace',
        env=environment or dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1'))
    with Path(log).open('a',encoding='utf-8') as stream:
        stream.write(json.dumps([str(a) for a in arguments],ensure_ascii=False)+'\n'+result.stdout+result.stderr+'\n')
    if result.returncode:
        raise RuntimeError(result.stderr[-6000:] or result.stdout[-6000:])
    return result.stdout


def load_plan(path):
    plan=read_json(path)
    if plan['owner_id'] != owner_id():
        raise ValueError('该安装计划属于另一Windows账号，请在本账号重新准备')
    runtime=Path(plan['runtime']).resolve()
    profile=Path(plan['profile']).resolve()
    skill=Path(plan['target']).resolve()
    if plan['isolated_test']:
        if not profile.is_relative_to(runtime) or not skill.is_relative_to(runtime):
            raise ValueError('隔离测试的配置和技能目录必须位于指定测试runtime内')
    elif profile != Store().root:
        raise ValueError('正式安装必须使用当前账号默认个人配置目录')
    if payload(SOURCE) != plan['payload'] or payload(Path(plan['candidate'])) != plan['payload']:
        raise ValueError('技能代码或候选副本已变化，请重新准备和审阅')
    if Path(sys.executable).resolve() != Path(plan['python']).resolve():
        raise ValueError('请用安装计划记录的专用Python执行')
    return plan


def review(plan):
    draft=Path(plan['draft'])
    text=f"""# 当前Windows账号：初始规则待确认

这是新账号的初始安装草案，尚未初始化正式个人版本。

- 技能目录：`{plan['target']}`
- 个人配置目录：`{plan['profile']}`
- 专用Python：`{plan['python']}`
- 核心功能测试：[查看结果](<{Path(plan['workflow_report']).as_posix()}>)
- 初始验证报告：[查看报告](<{(draft/'validation.json').as_posix()}>)
- 账号兼容修正：[具体代码差异](<{(BUNDLE/'账号兼容修正.diff').as_posix()}>)。使用USERPROFILE与Windows ProfileList匹配账号SID，避免沙箱进程SID误判；审批逻辑不变，不自动接管已有不同SID配置。本次确认包含此项固定控制文件的兼容修改及以下初始规则。
- 几何预览位于draft/previews；图像是安装测试示意图，不代表真实商品审美效果。

本版本包含每批商品主体选择与各品类取景规则：上衣／外套、裤子、眼镜／雪镜、帽子、鞋／靴、全身及自定义。已明确品类时直接采用；单批选择不自动成为长期默认。由Codex逐图观察并规划，不是脚本新增品类检测或固定坐标。

以下3份新文件将构成同一个版本：settings.json、personal_prompt.md、renderer.py。

```json
{(draft/'snapshot/settings.json').read_text(encoding='utf-8').strip()}
```

{(draft/'snapshot/personal_prompt.md').read_text(encoding='utf-8')}

每批成功完成询问一次；文字、参数和图片路径存入本账号。明确长期偏好立即提议，其余同类意见来自3个不同批次再提议。同一批重复不累加。

长期修改先展示具体差异和测试预览，由本账号用户批准后生效；测试失败不生效，运行异常由用户选择是否回退。保留总共3个已生效版本，含当前版。

初始摘要：`{plan['digest']}`

请用户查看本草案和预览后明确批准，再调用Activate。测试程序里的确认文字不能用作正式账号批准。
"""
    (draft/'待确认初始规则.md').write_text(text,encoding='utf-8')


def refresh(path):
    plan=load_plan(path)
    if plan['status'] != 'prepared':
        raise ValueError('只能验证尚未激活的草案')
    report=validate_snapshot(Path(plan['draft'])/'snapshot',Path(plan['draft'])/'previews',read_json(plan['spec'])['jobs'])
    write_json(Path(plan['draft'])/'validation.json',report)
    plan['digest']=snapshot_digest(Path(plan['draft'])/'snapshot')
    plan['validation_passed']=report['passed']
    write_json(path,plan)
    review(plan)
    if not report['passed']:
        raise ValueError('初始规则验证失败：'+report.get('error','未知错误'))
    return plan


def prepare(args):
    from PIL import Image,ImageDraw
    runtime=Path(args.runtime).resolve()
    target=Path(args.target).resolve()
    runtime.mkdir(parents=True,exist_ok=True)
    session=runtime/'logs'/('prepare-'+identifier())
    session.mkdir(parents=True)
    profile=Path(args.test_profile).resolve() if args.test_profile else Store().root
    test_mode=bool(args.test_profile)
    if test_mode and (not profile.is_relative_to(runtime) or not target.is_relative_to(runtime)):
        raise ValueError('测试配置和技能必须位于同一隔离runtime内')
    if Store(profile).status()['initialized']:
        raise ValueError('当前账号已有正式配置，不能重新init；须保留现有版本并经提案审批迁移')
    candidate=runtime/'staging'/identifier()/'chutu-chicun-tiaozheng'
    shutil.copytree(SOURCE,candidate)
    import yaml
    metadata=yaml.safe_load((candidate/'SKILL.md').read_text(encoding='utf-8').split('---',2)[1])
    if metadata.get('name') != 'chutu-chicun-tiaozheng' or not metadata.get('description'):
        raise ValueError('技能frontmatter缺少正确name或description')
    write_json(candidate/'runtime.json',{'schema':1,'python':str(Path(sys.executable).resolve()),'runtime':str(runtime)})
    environment=dict(os.environ,RESIZE_TEST_SKILL=str(candidate),PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    result_file=session/'workflow-tests.txt'
    print('Running resize, feedback, approval and rollback regression tests...',flush=True)
    run([sys.executable,BUNDLE/'tests/test_workflow.py'],result_file,environment)
    src=session/'sources';src.mkdir()
    portrait=Image.new('RGB',(600,900),'#94bed7')
    draw=ImageDraw.Draw(portrait)
    draw.ellipse((240,140,360,260),fill='#edbc98')
    draw.rounded_rectangle((175,265,425,750),35,fill='#dc7984')
    draw.rectangle((0,780,600,900),fill='#547b93')
    portrait.save(src/'竖版示意.jpg',quality=95)
    wide=Image.new('RGB',(1000,500),'#a0c1bd')
    draw=ImageDraw.Draw(wide);draw.rounded_rectangle((330,85,690,430),45,fill='#4f8bb0')
    wide.save(src/'横版示意.png')
    jobs=[{'input':str(src/'竖版示意.jpg'),'name':'portrait-square','size':'800x800','focus':[.5,.39],'protect_box':[.30,.15,.70,.65]},
          {'input':str(src/'竖版示意.jpg'),'name':'portrait-vertical','size':'750x1000','focus':[.5,.5]},
          {'input':str(src/'横版示意.png'),'name':'landscape-square','size':'1440x1440','focus':[.51,.5]}]
    spec=session/'preview-jobs.json';write_json(spec,{'jobs':jobs})
    draft=runtime/'drafts'/identifier()
    print('Creating a separate initial draft and previews; not activating the account.',flush=True)
    run([sys.executable,candidate/'scripts/prepare_initial.py','--out',draft,'--spec',spec],session/'prepare-draft.log')
    plan={'schema':1,'status':'prepared','owner_id':owner_id(),'python':str(Path(sys.executable).resolve()),
          'runtime':str(runtime),'target':str(target),'profile':str(profile),'isolated_test':test_mode,
          'candidate':str(candidate),'payload':payload(SOURCE),'draft':str(draft),'spec':str(spec),
          'workflow_report':str(result_file),'session':str(session),'digest':snapshot_digest(draft/'snapshot'),
          'validation_passed':read_json(draft/'validation.json')['passed']}
    plan_path=runtime/'installation-plan.json';write_json(plan_path,plan);review(plan)
    print(json.dumps({'prepared':True,'activated':False,'plan':str(plan_path),'digest':plan['digest'],
        'review':str(draft/'待确认初始规则.md'),'previews':str(draft/'previews'),
        'next':'向该账号用户展示规则和预览，得到真实批准后Activate'},ensure_ascii=False,indent=2))


def activate(args):
    plan=load_plan(args.plan)
    if plan['status'] != 'prepared':
        raise ValueError('安装计划已激活或处于异常中间状态，请检查记录，不重复初始化')
    confirmation=Path(args.confirmation_file).read_text(encoding='utf-8-sig').strip()
    if not confirmation:
        raise ValueError('缺少用户本次查看草案后的真实确认原文')
    draft=Path(plan['draft'])
    if args.digest != plan['digest'] or args.digest != snapshot_digest(draft/'snapshot'):
        raise ValueError('确认摘要与初始草案不同，重新验证和审阅')
    from user_profile import require_validation
    require_validation(draft/'snapshot',read_json(draft/'validation.json'))
    session=Path(plan['session']);target=Path(plan['target']);candidate=Path(plan['candidate'])
    backup=None
    if target.exists():
        backup=Path(plan['runtime'])/'backups'/identifier()/'chutu-chicun-tiaozheng'
        shutil.copytree(target,backup)
    revision=Store(plan['profile']).initialize(draft/'snapshot',confirmation,read_json(draft/'validation.json'))
    plan.update(status='profile-initialized',revision=revision,backup=str(backup) if backup else None)
    write_json(args.plan,plan)
    names=[p.relative_to(candidate) for p in candidate.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    for name in sorted(names,key=lambda p:(p.as_posix()=='SKILL.md',p.as_posix())):
        output=target/name;output.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(candidate/name,output)
        if file_hash(candidate/name) != file_hash(output):
            raise ValueError('安装文件摘要不一致：'+str(name))
    preview=session/'installed-preview.png'
    command=['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',target/'scripts/run_resize.ps1']
    if plan['isolated_test']:
        command+=['--state',plan['profile']]
    command+=['preview','--spec',plan['spec'],'--out',preview,'--limit','0']
    run(command,session/'installed-preview.log')
    status=Store(plan['profile']).status()
    if status['digest'] != args.digest or status['revision'] != revision:
        raise ValueError('已安装个人版本与批准快照不一致')
    if Store(plan['profile']).events('feedback.jsonl') or list((Path(plan['profile'])/'batches').glob('*.json')):
        raise ValueError('安装预览不应产生正式批次或用户反馈')
    receipt={'passed':True,'activated':True,'revision':revision,'digest':args.digest,'profile':plan['profile'],
             'skill':str(target),'python':str(Path(sys.executable).resolve()),'preview':str(preview),
             'workflow_report':plan['workflow_report'],'initial_validation':str(draft/'validation.json'),
             'confirmation':confirmation,'backup':str(backup) if backup else None,'isolated_test':plan['isolated_test']}
    write_json(Path(plan['runtime'])/'installation.json',receipt)
    plan['status']='activated';write_json(args.plan,plan)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='mode',required=True)
    p=sub.add_parser('prepare');p.add_argument('--runtime',required=True);p.add_argument('--target',required=True);p.add_argument('--test-profile')
    p=sub.add_parser('refresh');p.add_argument('--plan',required=True)
    p=sub.add_parser('activate');p.add_argument('--plan',required=True);p.add_argument('--digest',required=True);p.add_argument('--confirmation-file',required=True)
    args=parser.parse_args()
    if args.mode=='prepare':prepare(args)
    elif args.mode=='refresh':
        plan=refresh(args.plan);print(json.dumps({'passed':True,'digest':plan['digest'],'draft':plan['draft']},ensure_ascii=False))
    else:activate(args)


if __name__=='__main__':
    main()
