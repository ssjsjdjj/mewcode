#!/usr/bin/env python3
"""正式调用入口：读取本 Windows 账号已批准版本，执行后提示一次批次反馈。"""
import argparse
import json
import sys

from user_profile import Store, effective_job
from validate_candidate import assert_render, load_engine


def run(store, argv):
    with store.lock():
        revision, folder, settings = store.active()
        engine = load_engine(folder)
    original_resolve, original_render = engine.resolve_job, engine._render
    original_make, original_batch = engine.make, engine.batch
    in_batch, logged = False, False

    def report(error, job=None):
        nonlocal logged
        if not logged:
            incident = store.incident(error, job)
            print(json.dumps({"incident": incident, "rollback_choices": store.version_list()}, ensure_ascii=False), file=sys.stderr)
            logged = True

    def resolve(job):
        return original_resolve(effective_job(settings, job))

    def render(job):
        actual = effective_job(settings, job)
        try:
            src, image, plan, resolved = original_render(actual)
            assert_render(image, plan, resolved)
            return src, image, plan, resolved
        except Exception as error:
            report(error, actual)
            raise

    def make(job):
        try:
            result = original_make(effective_job(settings, job))
            if not in_batch:
                result["feedback"] = store.register_batch([effective_job(settings, job)], [result], revision, settings["feedback"]["mode"])
            result["personal_revision"] = revision
            return result
        except Exception as error:
            report(error, job)
            raise

    def batch(jobs):
        nonlocal in_batch
        in_batch = True
        try:
            result = original_batch([effective_job(settings, job) for job in jobs])
            feedback = store.register_batch([effective_job(settings, job) for job in jobs], result, revision, settings["feedback"]["mode"])
            if result:
                result[0]["feedback"] = feedback
            return result
        except Exception as error:
            report(error)
            raise
        finally:
            in_batch = False

    engine.resolve_job, engine._render = resolve, render
    engine.make, engine.batch = make, batch
    previous = sys.argv
    sys.argv = [str(folder / "renderer.py"), *argv]
    try:
        engine.main()
    finally:
        sys.argv = previous


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--state")
    args, remaining = parser.parse_known_args()
    try:
        run(Store(args.state), remaining)
    except Exception as error:
        print(f"[错误] {error}", file=sys.stderr)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
