# 账号、反馈和审批命令

## 账号目录与首次启用

Python 3.9+、Pillow 9.1+。使用本机已验证可用的解释器；不要假设 `py` 一定安装。正常运行不需要联网，普通尺寸调整不依赖 `psd-tools`。

下文在技能目录运行，`python` 代表可用解释器；中文乱码先设置 `$env:PYTHONIOENCODING='utf-8'`。所有 JSON 用 UTF-8，路径优先用绝对路径。

```powershell
python scripts/user_profile.py status
python scripts/prepare_initial.py --out "D:/测试/初始草案" --spec "D:/测试/样例任务.json"
```

正式目录固定为当前 Windows 账号的 `%LOCALAPPDATA%/ChutuResize`。迁移版用 `USERPROFILE` 在Windows `ProfileList`匹配所属SID来检查归属，避免Codex沙箱进程SID造成误判；匹配失败或有歧义时停止。这是按账号隔离的工作流程，不额外改变 Windows ACL，也不是防止管理员读取其他账号文件的加密系统。账号切换即切换默认根目录。新账号需单独确认初始规则；不能拷贝他人 `owner.json`、反馈或版本库，也不自动迁移SID不一致的旧状态。模板里的规则是起点，当前账号的偏好经其确认才能启用。

首次草案生成在用户选定的测试目录，包含 `snapshot`、验证报告和预览，不产生正式配置。向用户展示初始规则及实际样例；确认后才执行：

```powershell
# 下列占位文字必须换成用户这次真实的批准原文。
python scripts/user_profile.py init --snapshot "D:/测试/初始草案/snapshot" --validation "D:/测试/初始草案/validation.json" --confirmation "<用户实际批准原文>"
```

若用户要求修改草案，编辑 snapshot 后重新调用 `validate_snapshot`（见文末）刷新验证；旧报告不会通过。已有账号不能重复 `init`，必须走待审提案。正常运行入口为 `scripts/resize_assets.py`，会加载 `current.json` 指向的三份个人文件。

目录结构：

```text
ChutuResize/
  owner.json                  Windows SID
  current.json                当前已批准版本及摘要
  versions/v-.../              配置、提示词、裁切脚本、版本记录
  batches/b-....json           实际参数、原图路径、输出路径、是否已询问
  feedback.jsonl              文字、参数、图片路径，不复制原图
  proposals/p-.../             候选副本、精确差异、测试报告及预览
  incidents.jsonl             异常；没有自动回退
  audit.jsonl                 生效和回退的确认记录
```

测试时才用 `--state "D:/测试/独立账号状态"`；其权限与归属检查仍然有效。不要用这个选项指向别人的账号目录。

## 一批结束，询问一次

`make` 算一批；一个 `batch --spec` 无论多少张只算一批。预览不注册完成批次。成功结果含 `feedback.batch_id`、`feedback_due`，批量时只在第一项返回。记录已捕获的版本号，防止并行任务中途变更规则造成归属混乱。

```powershell
python scripts/user_profile.py mark-asked --batch "<批次ID>"
```

仅在返回 `ask_now:true` 时向用户展示本批结果并问一次，例如“这批构图满意吗？可说明主体大小、白边、位置或要保留的部位，也可跳过。”不把继续下一批或沉默记成满意。用户回复后记录；不再循环催问。

## 解释和收集反馈

范围：`once` 仅此次；`general` 未明确长期的可复用反馈；`long_term` 用户明确说以后/默认/长期。若只说“这张往上些”，按 once。若不清楚是批次修改还是长期偏好，先询问。单纯满意但没有可提炼的修改时，可用 once 记录此次评价，不累计成修改建议。

同类需有相同、具体主题和相同结构化修改；不要把相反反馈都放进 `position` 这类宽泛主题。自然语言语义判断由 Codex完成，脚本只按 `topic` 和 `desired_patch` 计数，不使用词向量或训练模型。

```powershell
python scripts/user_profile.py feedback --batch "<批次ID>" --text "仅这张向上挪一点" --topic "single_image_move_up" --scope once
python scripts/user_profile.py feedback --batch "<批次ID>" --text "以后所有场景图不要新增白边" --topic "scene_no_added_border" --scope long_term --patch "D:/测试/规则修改.json"
```

`规则修改.json` 可为：

```json
{"defaults":{"fit":"cover","allow_padding":false,"on_conflict":"error"}}
```

补丁仅可表达用户明确反馈；不要将“自然美观”直接等价为固定焦点、统一放大倍数或裁切比例。无精确参数则省略 `--patch`，仅提提示词草案。普通反馈需来自 3 个不同批次，同批重复不累加；明确长期偏好立即提议。记录反馈不会更新正式版本。

脚本先生成保守的参数/提示词草案。Codex应检查其内容：合并重复规则，替换明确被取代的旧规则；范围有冲突先询问。修改 `candidate` 后必须重新验证，验证会重建精确差异和摘要。若相同规则已存在，先检查实际执行参数、旧入口或程序行为，不能靠反复追加提示词解决。

## 草案、验证、一次确认

能力不足或程序错误才考虑 `renderer.py`。在独立目录放被修改的文件，文件名仅限 `settings.json`、`personal_prompt.md`、`renderer.py`。程序修改前理解原有行为，加入针对此问题的实际回归样例；保留几何与原图保护检查。不得用反馈渠道修改控制器或验证器。

```powershell
python scripts/user_profile.py propose --changes "D:/测试/修改文件" --summary "修复保护区域冲突时的构图错误"
python scripts/user_profile.py validate --proposal "<草案ID>" --spec "D:/测试/复现任务.json"
```

验证只在内存渲染与单独预览，不把任务单中的 `out_dir` 当作正式输出位置。包含尺寸/比例/补边政策/禁止覆盖原图检查。必须选择能复现反馈的真实素材，并检查代表性不同构图；合成示意图只是基础检查，不能单独证明审美改善。

验证后读取 `proposal.json` 最新摘要、`changes.diff`、`review.md`、`validation.json`，给用户看：具体改了什么、适用范围、硬性测试是否通过、原图与候选结果预览、已知影响。脚本更改还需说明回归验证。一次确认后：

```powershell
python scripts/user_profile.py approve --proposal "<草案ID>" --digest "<已展示且验证通过的最新摘要>" --confirmation "<用户本次实际批准原文>"
# 不同意则记录原因，正式版本不变
python scripts/user_profile.py reject --proposal "<草案ID>" --reason "用户希望调整适用范围"
```

不能为追求自动化捏造确认。脚本检查确认字符串非空，无法判断真实发言者；Codex负责核对人类消息与所审草案。测试程序里的“批准”只用于隔离测试，不能授权正式账号。

审批绑定候选三文件的 SHA256 组合摘要、当前基线版本、通过的测试、测试原图和预览摘要。任一发生变化或草案过时则拒绝，重新测试和展示。保留总共 3 个有效版本（含当前版）；已应用候选的完整副本会删除，完整历史只在 versions 中按此数量保留。待审/驳回草案和差异日志可能另有记录，但不作为可回退正式版本。

## 异常和手动回退

错误大小、非授权补边/拉伸会在写图前检查。出错后停止当前批次并报告，已完成的其他图片可能已存在，不自动删除。部分输入/路径错误也会被记录，不能把所有异常都归咎于审美规则。查看原因、可回退版本和影响，让用户选择；未回复不回退。

```powershell
python scripts/user_profile.py versions
python scripts/user_profile.py rollback --revision "<用户选择的已保留版本>" --confirmation "<用户实际同意回退的原文>"
```

回退切换已批准的完整配置、提示词和脚本。旧版本超过保留数量则不可回退。路径被移动/图片删除时无法复现原反馈，应先重新定位源图；反馈存储不保留原图备份。

## 编辑初始草案后重新验证

在技能目录创建一次性 Python 驱动，调用固定验证器：

```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "scripts"))
from user_profile import read_json, write_json
from validate_candidate import validate_snapshot
spec = read_json("D:/测试/样例任务.json")
jobs = [{**spec.get("defaults", {}), **item} for item in spec["jobs"]]
report = validate_snapshot("D:/测试/初始草案/snapshot", "D:/测试/初始草案/previews", jobs)
write_json("D:/测试/初始草案/validation.json", report)
```
