# Windows迁移版

本包使用最终个人反馈版的裁切器、控制器和验证器，裁切、入口及验证等4份Python核心文件保持一致；`user_profile.py`只修正登录账号SID定位，避免把Codex沙箱进程SID当成用户SID。源版本和兼容差异见迁移包根目录`源版本.json`与`账号兼容修正.diff`，发布前与初始规则一并确认。另增加专用Python路径记录和PowerShell入口，避免新电脑依赖系统py命令、PATH或旧`.ps-asset-pipeline`副本。

1. `runtime.json`位于本技能目录，`python`字段是专用虚拟环境的解释器绝对路径。文中python示例都应替换成该解释器。
2. `run_profile.ps1`转发user_profile.py的参数，`run_resize.ps1`转发resize_assets.py的参数，不要用PowerShell参数绑定包装Python的--out等参数。
3. 正常个人状态使用当前Windows账号的`LOCALAPPDATA/ChutuResize`，执行中不传--state；仅明确隔离测试可以使用--state。运行环境另存于`LOCALAPPDATA/ChutuResizeRuntime`，二者用途不同。
4. 每个Windows账号需在自己的目录安装、确认和初始化。不要复制其他账号的owner.json、current.json、feedback.jsonl、batches或versions目录。模板里的初始规则不意味着新用户已批准。

首次安装流程：运行迁移包`install.ps1 -Mode Prepare`，完成依赖、功能测试和初始规则预览；把返回的待确认说明、完整初始参数、提示词、裁切器摘要及预览给用户看。用户明确同意后，将真实回复保存为UTF-8文件，再运行`-Mode Activate -PlanPath <计划> -Digest <已审阅摘要> -ConfirmationFile <真实确认文件>`。不能把自动化测试里的确认原文用于正式账号。

初始草案修改后，先运行`-Mode Refresh -PlanPath <计划>`更新报告、预览和摘要，再展示给用户。初始草案和已生效版本的日常反馈提案不同：日常继续走user_profile.py的propose/validate/approve，不重跑init。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_profile.ps1" status
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_resize.ps1" preview --spec "D:/工作/本批.json" --out "D:/工作/预览.png"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_resize.ps1" batch --spec "D:/工作/本批.json"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_profile.ps1" mark-asked --batch "<本批ID>"
```

固定规则和反馈步骤见SKILL.md及feedback-workflow.md。PSD是可选的单图层结果文件，不含原图的主体/背景分层。PNG原有的透明背景不属于“新增补边”；几何检查不会清除源图既有白边、雪地或透明区域。

这不是强化学习模型；无模型下载、无抠图依赖，不需要Photoshop、GPU、CUDA或API密钥。自然构图仍由Codex逐图观察、规划裁切框并以预览确认。

## 商品主体选择

本版同步每批主体选项：上衣／外套、裤子、眼镜／雪镜、帽子、鞋／靴、全身穿搭，支持自定义。新账号初始草案包含各品类取景规则，经该账号确认后执行；每批选择本身不自动变成长久默认。用户已明确品类时直接采用，目录名和旧满意反馈不能代替选择。

选择后由Codex观察真实照片，将商品特性转成逐图的有效裁切框和保护范围。说明见[product-focus.md](product-focus.md)。裁切脚本没有新增品类识别模型、固定品类坐标或--category参数；依赖安装与原有审批、反馈和版本规则继续使用。
