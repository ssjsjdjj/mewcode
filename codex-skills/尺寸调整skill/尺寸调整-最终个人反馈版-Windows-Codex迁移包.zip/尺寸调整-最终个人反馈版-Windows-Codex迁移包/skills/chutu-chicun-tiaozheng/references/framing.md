# 构图与批量任务

裁切器版本 3.0.0。正式入口 `scripts/resize_assets.py` 读取本账号已批准的配置、提示词对应版本的裁切脚本；不用旧 `.ps-asset-pipeline`。Python 3.9+、Pillow 9.1+。坐标基于 EXIF 方向纠正后的原图；框 `[left,top,right,bottom]` 均为 0~1，右下为外边界，crop_box 不改变其他框的坐标系。

| 参数 | 用途 |
|---|---|
| size | 必填目标宽高，例如 800x800；1~10000 |
| fit | cover 铺满；contain 完整显示；subject 按指定框构图；stretch 拉伸 |
| crop_box | 先限制源区域，仍用原图坐标，不能排除必须保留框 |
| focus | cover 的原图焦点 `[x,y]`；缺省为所选区域中心 |
| position | 焦点/主体中心在目标画布的位置，默认 `[0.5,0.5]` |
| offset | 相对目标宽高的平移 `[dx,dy]`，正数向右/下，范围 -1~1 |
| zoom | cover 1~10；contain 0.05~1；subject 需为 1 |
| subject_box | 人工指定主体框；所有模式需完整保留；subject 模式必需 |
| subject_fill | subject 较大方向占对应目标方向比例，0.05~1，不是面积占比 |
| protect_box | 额外必须保留矩形，可用商品及关键动作的联合框 |
| on_conflict | 当前账号默认 error；contain 回退只有明确 allow_padding:true 才能使用 |
| allow_padding | 默认 false；禁止取景范围超出源区域而新增白边/透明边 |
| allow_stretch | 默认 false；本次用户明确授权拉伸才覆盖 |
| format | keep / jpg / png / webp；缺省读取个人配置 |
| save_recipe | 保存 .framing.json；默认读取个人配置 |

不留新增白边不会清除原图既有的白墙或透明区域；有此需求先说明并另定处理方案。平移受原图边界限制，不创造背景。subject 的占比与位置可能无法同时实现，检查 warnings 和预览，不能静默补白。

预设是初始参数，不是视觉识别：product 使用 subject/80%；full_body 使用 subject/88%；half_body 为 cover/焦点 `[0.5,0.38]`；detail 为 cover/放大 1.15。前两个缺主体框时退回 cover 并提示需要预览；这不保证全貌，应补人工框或改任务方案。先由个人默认参数与个人 preset_defaults 合并，再由本次显式任务参数覆盖；本次覆盖不自动持久化。

## 示例

示例坐标不能直接套用实际照片。下文在技能目录运行，`python` 替换为本机可用解释器。正常账号已完成初始化。

```powershell
python scripts/resize_assets.py make --input "D:/素材/模特.jpg" --size 800x800 --fit cover --focus "0.5,0.32" --protect-box "0.25,0.15,0.75,0.65" --out-dir "D:/结果/本批"
python scripts/resize_assets.py preview --spec "D:/任务/本批.json" --out "D:/任务/预览.png" --limit 0
python scripts/resize_assets.py batch --spec "D:/任务/本批.json"
```

CLI 坐标用逗号分隔。负号开头用等号形式 `--offset=-0.03,0`。只有用户明确要求，本次才使用 `--allow-padding` 或 `--allow-stretch`。用户明确要拉伸时通常还需 `--fit stretch`。确认长期规则另走反馈审批。

```json
{
  "defaults": {
    "size": "800x800",
    "format": "jpg",
    "out_dir": "D:/结果/本批",
    "save_recipe": false
  },
  "jobs": [
    {
      "input": "D:/素材/模特.jpg",
      "focus": [0.5,0.32],
      "protect_box": [0.25,0.15,0.75,0.65]
    }
  ]
}
```

路径优先绝对路径；相对路径按工作目录解析。`preview --limit 0` 展示全部；不生成正式图片，不触发完成批次反馈。batch 在写图前检查全部任务的几何及覆盖原图冲突，但硬盘写入中途失败仍可能有部分结果。

同名输出可能覆盖，应使用新目录或名称；脚本拒绝覆盖任何本批原图。PSD 需 psd-tools，只包含结果图的单图层，不能还原原图分层。

保存 recipe 时可 `replay --recipe "D:/结果/本批/模特.framing.json" --out-dir "D:/结果/重做"`。源图 SHA256、裁切器版本需匹配；2.0 旧 recipe 不直接兼容 3.0。不同 Pillow/编码环境不能承诺逐字节一致。通过个人入口重放仍受当前个人硬性规则检查；规则冲突时先向用户说明，不绕过入口。

## 商品主体选择

裁切前先确定主体，流程见 [product-focus.md](product-focus.md)。本次category/emphasis属于任务说明，不是新的裁切模式；Codex需逐图把商品特性转成有效crop_box、focus及保护范围。裁切器没有品类视觉识别，不支持--category命令。固定预设不能代替商品定位。
