﻿[CmdletBinding()]
param(
    [string]$PythonExe = '',
    [string]$RuntimeRoot = '',
    [string]$SkillRoot = '',
    [string]$IndexUrl = 'https://pypi.org/simple'
)
$ErrorActionPreference = 'Stop'
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$BundleRoot = $PSScriptRoot
$Utf8 = New-Object System.Text.UTF8Encoding($false)
if (-not [Environment]::Is64BitOperatingSystem) { throw '本包需要64位Windows；当前系统不支持此CPU依赖组合。' }
if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'LOCALAPPDATA缺失，不能定位当前账号运行环境。' }
if (-not $RuntimeRoot) { $RuntimeRoot = Join-Path $env:LOCALAPPDATA 'ChutuBaidiTouming' }
if (-not $SkillRoot) { $SkillRoot = Join-Path $HOME '.agents\skills\chutu-baidi-touming' }
$RuntimeRoot = [IO.Path]::GetFullPath($RuntimeRoot)
$SkillRoot = [IO.Path]::GetFullPath($SkillRoot)

function Step([string]$Text) { Write-Host $Text -ForegroundColor Cyan }
function Confirm-Payload {
    $ManifestFile = Join-Path $BundleRoot 'MANIFEST.json'
    if (-not (Test-Path -LiteralPath $ManifestFile)) { throw '迁移包缺少MANIFEST.json，请重新传入完整安装包。' }
    $Manifest = Get-Content -LiteralPath $ManifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($Property in $Manifest.files.PSObject.Properties) {
        $Candidate = [IO.Path]::GetFullPath((Join-Path $BundleRoot $Property.Name))
        $Boundary = [IO.Path]::GetFullPath($BundleRoot).TrimEnd('\') + '\'
        if (-not $Candidate.StartsWith($Boundary,[StringComparison]::OrdinalIgnoreCase)) { throw '文件清单路径越界。' }
        if (-not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { throw "迁移包缺少文件：$($Property.Name)" }
        $Actual = (Get-FileHash -LiteralPath $Candidate -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($Actual -ne $Property.Value) { throw "文件校验失败：$($Property.Name)" }
    }
}
function Test-Python([string]$Candidate) {
    if (-not $Candidate -or -not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { return $false }
    $Probe = "import sys,struct,venv,ensurepip,platform; assert sys.version_info[:2] in [(3,12),(3,13)]; assert struct.calcsize('P')==8; assert platform.machine().lower() in ('amd64','x86_64'); print(sys.executable)"
    $PreviousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $ProbeOutput = & $Candidate -c $Probe 2>&1
        return ($LASTEXITCODE -eq 0)
    }
    finally { $ErrorActionPreference = $PreviousPreference }
}
function Find-Python {
    $Candidates = @()
    if ($PythonExe) { $Candidates += $PythonExe }
    $Candidates += (Join-Path $HOME '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
    foreach ($Version in @('3.12','3.13')) {
        $Candidates += (Join-Path $env:LOCALAPPDATA ('Programs\Python\Python' + $Version.Replace('.','') + '\python.exe'))
        foreach ($Hive in @('HKCU:','HKLM:')) {
            $Key = "$Hive\Software\Python\PythonCore\$Version\InstallPath"
            if (Test-Path -LiteralPath $Key) {
                $Value = (Get-Item -LiteralPath $Key).GetValue('')
                if ($Value) { $Candidates += (Join-Path $Value 'python.exe') }
            }
        }
    }
    foreach ($CommandName in @('python.exe','python3.exe')) {
        $Command = Get-Command $CommandName -ErrorAction SilentlyContinue
        if ($Command -and $Command.Source -notmatch '\\WindowsApps\\') { $Candidates += $Command.Source }
    }
    foreach ($Candidate in ($Candidates | Select-Object -Unique)) {
        if (Test-Python $Candidate) { return [IO.Path]::GetFullPath($Candidate) }
    }
    return $null
}
function Run-Python([string]$Executable,[string[]]$Arguments) {
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Python命令失败，退出码${LASTEXITCODE}：$($Arguments -join ' ')" }
}

Confirm-Payload
$SourceSkill = Join-Path $BundleRoot 'skills\chutu-baidi-touming'
if ($SkillRoot.TrimEnd('\') -eq [IO.Path]::GetFullPath($SourceSkill).TrimEnd('\')) { throw '安装目录不能与迁移包源目录相同。' }
New-Item -ItemType Directory -Path $RuntimeRoot -Force | Out-Null
$RunId = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$LogDirectory = Join-Path $RuntimeRoot "logs\install-$RunId"
New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
$TranscriptStarted = $false
try {
    Start-Transcript -LiteralPath (Join-Path $LogDirectory 'install.log') | Out-Null
    $TranscriptStarted = $true
    Step '1/6 定位兼容的64位Python，不依赖py和PATH刷新'
    $BasePython = Find-Python
    if (-not $BasePython) {
        if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
            throw '没有可用Python，也没有winget。请Codex从python.org安装当前兼容的64位Python 3.12/3.13，再用-PythonExe传入绝对路径续跑。'
        }
        & winget.exe install --id Python.Python.3.13 -e --scope user --silent --disable-interactivity --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -notin @(0,3010)) { throw "Python安装失败，winget退出码$LASTEXITCODE；请Codex诊断后从官方安装源补齐。" }
        $BasePython = Find-Python
        if (-not $BasePython) { throw 'Python安装后仍未找到可用解释器。请Codex定位实际python.exe并以-PythonExe续跑，不必让用户手动设置PATH。' }
    }
    Step '2/6 创建当前账号的独立环境并安装依赖'
    $EnvironmentDirectory = Join-Path $RuntimeRoot 'venv'
    $DedicatedPython = Join-Path $EnvironmentDirectory 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $DedicatedPython)) {
        Run-Python $BasePython @('-m','venv',$EnvironmentDirectory)
    }
    if (-not (Test-Python $DedicatedPython)) { throw '现有专用环境不兼容；保留现场，请Codex诊断，不自动删除。' }
    $env:PIP_CACHE_DIR = Join-Path $RuntimeRoot 'cache\pip'
    Run-Python $DedicatedPython @('-m','pip','install','--disable-pip-version-check','--upgrade','pip','--index-url',$IndexUrl,'--timeout','60','--retries','2')
    $RequirementFile = Join-Path $BundleRoot 'requirements-lock.txt'
    if (-not (Test-Path -LiteralPath $RequirementFile)) { $RequirementFile = Join-Path $BundleRoot 'requirements.txt' }
    Run-Python $DedicatedPython @('-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--index-url',$IndexUrl,'--timeout','60','--retries','2','-r',$RequirementFile)
    Run-Python $DedicatedPython @('-m','pip','check')
    Step '3/6 准备候选技能及账号独立模型目录'
    $StageParent = Join-Path $RuntimeRoot "staging\$RunId"
    New-Item -ItemType Directory -Path $StageParent -Force | Out-Null
    $StageSkill = Join-Path $StageParent 'chutu-baidi-touming'
    Copy-Item -LiteralPath $SourceSkill -Destination $StageSkill -Recurse
    $ModelDirectory = Join-Path $RuntimeRoot 'models'
    $CacheDirectory = Join-Path $RuntimeRoot 'cache'
    New-Item -ItemType Directory -Path $ModelDirectory -Force | Out-Null
    New-Item -ItemType Directory -Path $CacheDirectory -Force | Out-Null
    $Config = @{schema=1;python=$DedicatedPython;model_dir=$ModelDirectory;cache_dir=$CacheDirectory;cpu_threads=1;process_priority='below_normal';allow_spinning=$false;model='u2net';installed_at=(Get-Date).ToString('o')}
    [IO.File]::WriteAllText((Join-Path $StageSkill 'runtime.json'),($Config | ConvertTo-Json),$Utf8)
    Step '4/6 下载并实际运行u2net，严格验收JPG、PNG和PSD'
    $TestWork = Join-Path $LogDirectory 'selftest'
    Run-Python $DedicatedPython @((Join-Path $StageSkill 'scripts\selftest.py'),'--skill',$StageSkill,'--work',$TestWork)
    $TestReportFile = Join-Path $TestWork 'report.json'
    $TestReport = Get-Content -LiteralPath $TestReportFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $TestReport.passed -or -not $TestReport.model_inference) { throw '严格验收未通过，不能发布为安装成功。' }
    Step '5/6 备份已有同名技能，安装当前账号技能'
    $Backup = $null
    if (Test-Path -LiteralPath $SkillRoot) {
        $BackupParent = Join-Path $RuntimeRoot "backups\$RunId"
        New-Item -ItemType Directory -Path $BackupParent -Force | Out-Null
        $Backup = Join-Path $BackupParent 'chutu-baidi-touming'
        Copy-Item -LiteralPath $SkillRoot -Destination $Backup -Recurse
    }
    New-Item -ItemType Directory -Path $SkillRoot -Force | Out-Null
    foreach ($Entry in (Get-ChildItem -LiteralPath $StageSkill -Force | Where-Object { $_.Name -ne 'SKILL.md' })) {
        Copy-Item -LiteralPath $Entry.FullName -Destination $SkillRoot -Recurse -Force
    }
    Copy-Item -LiteralPath (Join-Path $StageSkill 'SKILL.md') -Destination (Join-Path $SkillRoot 'SKILL.md') -Force
    foreach ($File in (Get-ChildItem -LiteralPath $StageSkill -Recurse -File)) {
        $Relative = $File.FullName.Substring($StageSkill.Length).TrimStart('\')
        $Installed = Join-Path $SkillRoot $Relative
        if ((Get-FileHash -LiteralPath $File.FullName).Hash -ne (Get-FileHash -LiteralPath $Installed).Hash) { throw "安装文件校验失败：$Relative" }
    }
    Step '6/6 核对已安装入口并输出验收记录'
    Run-Python $DedicatedPython @((Join-Path $SkillRoot 'scripts\launch.py'),'-h')
    $InstalledPreview = Join-Path $LogDirectory 'installed-preview.png'
    # The selftest output already exists, so use a fresh formal root for the
    # installed-entry preview rather than reusing a completed batch spec.
    $PreviewSpec = Get-Content -LiteralPath (Join-Path $TestWork 'separate-2-3.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $PreviewFormalRoot = Join-Path $LogDirectory 'preview-only-formal-output'
    $PreviewSpec.defaults.out_dir = $PreviewFormalRoot
    $PreviewSpecFile = Join-Path $LogDirectory 'installed-preview-job.json'
    [IO.File]::WriteAllText($PreviewSpecFile,($PreviewSpec | ConvertTo-Json -Depth 12),$Utf8)
    $PreviewResultText = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SkillRoot 'scripts\run_bg.ps1') preview --spec $PreviewSpecFile --out $InstalledPreview --limit 0
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $InstalledPreview)) { throw '已安装PowerShell入口的预览验收失败。' }
    $PreviewResult = ($PreviewResultText -join "`n") | ConvertFrom-Json
    if ($PreviewResult.input_count -ne 5 -or $PreviewResult.style_count -ne 2 -or $PreviewResult.image_count -ne 10 -or $PreviewResult.psd_count -ne 4 -or $PreviewResult.total_files -ne 14 -or $PreviewResult.shown -ne 5 -or $PreviewResult.formal_files_written -ne 0 -or (Test-Path -LiteralPath $PreviewFormalRoot)) { throw '已安装预览的款式/颜色/2N+2K计数或零正式文件检查失败。' }
    $Receipt = @{passed=$true;model_inference=$TestReport.model_inference;resource_mode='ps_priority';cpu_threads=$Config.cpu_threads;process_priority=$TestReport.inference_runtime.process_priority;allow_spinning=$Config.allow_spinning;skill=$SkillRoot;python=$DedicatedPython;runtime=$RuntimeRoot;model='u2net';model_path=$TestReport.model_path;checks_passed=$TestReport.passed_checks;checks_total=$TestReport.total_checks;test_report=$TestReportFile;preview=$InstalledPreview;preview_inputs=$PreviewResult.input_count;preview_styles=$PreviewResult.style_count;preview_expected_files=$PreviewResult.total_files;install_log=(Join-Path $LogDirectory 'install.log');backup=$Backup;installed_at=(Get-Date).ToString('o')}
    $ReceiptFile = Join-Path $RuntimeRoot 'installation.json'
    [IO.File]::WriteAllText($ReceiptFile,($Receipt | ConvertTo-Json -Depth 8),$Utf8)
    & $DedicatedPython -m pip freeze | Out-File -LiteralPath (Join-Path $LogDirectory 'installed-versions.txt') -Encoding UTF8
    $Receipt | ConvertTo-Json -Depth 8
    Write-Host '安装与功能验收通过。Codex若尚未列出技能，请新开对话；仍未显示再重启应用。' -ForegroundColor Green
}
catch {
    $Failure = @{passed=$false;error=$_.Exception.Message;log=$LogDirectory;at=(Get-Date).ToString('o')}
    [IO.File]::WriteAllText((Join-Path $LogDirectory 'failure.json'),($Failure | ConvertTo-Json),$Utf8)
    [Console]::Error.WriteLine($_.ToString())
    exit 1
}
finally {
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
}
