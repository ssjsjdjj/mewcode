"""Run the bundled processor with this account's private environment and CPU model."""
import json
import importlib.util
import os
import sys
from pathlib import Path


THREAD_VARIABLES = (
    "OMP_NUM_THREADS", "OMP_THREAD_LIMIT", "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS", "NUMBA_NUM_THREADS", "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS", "OPENCV_FOR_THREADS_NUM",
)


def configure_resources(config):
    """Apply this process's limits before any numeric library is imported."""
    threads = config.get("cpu_threads", 1)
    if type(threads) is not int or threads < 1:
        raise ValueError("runtime.json的cpu_threads必须为正整数")
    spinning = config.get("allow_spinning", False)
    if type(spinning) is not bool:
        raise ValueError("runtime.json的allow_spinning必须为布尔值")
    priority = config.get("process_priority", "below_normal")
    if priority != "below_normal":
        raise ValueError("本技能的PS优先模式使用process_priority=below_normal")
    for variable in THREAD_VARIABLES:
        os.environ[variable] = str(threads)
    os.environ["OMP_WAIT_POLICY"] = "PASSIVE"
    os.environ["KMP_BLOCKTIME"] = "0"
    actual_priority = "not_applicable"
    priority_class = None
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        kernel.SetPriorityClass.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        kernel.SetPriorityClass.restype = wintypes.BOOL
        kernel.GetPriorityClass.argtypes = (wintypes.HANDLE,)
        kernel.GetPriorityClass.restype = wintypes.DWORD
        process = kernel.GetCurrentProcess()
        if not kernel.SetPriorityClass(process, 0x4000):
            raise ctypes.WinError(ctypes.get_last_error())
        priority_class = kernel.GetPriorityClass(process)
        if priority_class != 0x4000:
            raise RuntimeError("未能核实Python进程为低于正常优先级")
        actual_priority = "below_normal"
    return {"mode": "ps_priority", "cpu_threads": threads, "allow_spinning": spinning,
            "process_priority": actual_priority, "priority_class": priority_class,
            "thread_environment": {key: os.environ[key] for key in THREAD_VARIABLES}}


def main():
    root = Path(__file__).resolve().parents[1]
    config = json.loads((root / "runtime.json").read_text(encoding="utf-8-sig"))
    expected_python = Path(config["python"]).resolve()
    if Path(sys.executable).resolve() != expected_python:
        raise RuntimeError("请使用本技能 run_bg.ps1 或 runtime.json 指定的专用 Python")
    resources = configure_resources(config)
    model_dir = Path(config["model_dir"])
    cache_dir = Path(config["cache_dir"])
    model_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)
    os.environ["U2NET_HOME"] = str(model_dir)
    os.environ["NUMBA_CACHE_DIR"] = str(cache_dir / "numba")
    os.environ["PYTHONIOENCODING"] = "utf-8"
    # The engine creates its local CPU session only when cutout actually needs it.
    # Help, planning, alpha inputs, queue and idle do not import rembg/numba.
    processor = root / "scripts/bg_assets.py"
    spec = importlib.util.spec_from_file_location("chutu_bg_processor", processor)
    engine = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(engine)
    engine.RUNTIME_SETTINGS = resources

    sys.argv[0] = str(processor)
    engine.main()


if __name__ == "__main__":
    main()
