---
name: chutu-baidi-touming
description: 出图-白底透明图：电商产品生成800×800白底JPG和透明PNG，每款汇总两份含各颜色图层的PSD；图片可分白底/透明文件夹或同款同目录。默认主体80%，先预览确认再后台生成，使用本机独立CPU环境，可选PS精修。
---

# 出图-白底透明图

在 Windows 本机用 Python、rembg CPU 和 psd-tools 后台处理。安装记录在本技能的 `runtime.json`，不使用其他账号或其他技能的 Python，不依赖 `py` 或命令行激活虚拟环境。只需后台白底、透明和PSD时不调用 Photoshop。

## 固定交付规则

- 固定800×800，不再问尺寸；默认主体较长方向占对应画布方向80%，等比居中。用户明确要求时可调整 fill，范围0.50～0.95。局部切图或改画布尺寸属于尺寸调整任务。
- 每张原图输出一张白底JPG和一张透明PNG。每款仅生成`款式-白底.psd`、`款式-透明.psd`两份汇总文件，同款多色及同色多角度均保留独立产品图层；不同款式分别输出，不能整批合为一对PSD。
- 白底PSD自下而上为白色「背景」层和各产品层，透明PSD只有各产品层。图层按任务单顺序命名为颜色；同色多角度命名为`颜色-角度/序号`。默认仅第一个产品层可见，其余隐藏，白底背景可见。各层位置与对应PNG一致，能够单独切换和编辑。
- N张输入、K款正式文件总数为`2N张图片+2K份PSD=2N+2K`。文件夹、预览、清单、任务单和日志不计入正式文件，辅助文件放工作目录。
- 已有有效透明通道的原图直接使用，不重复抠图。复杂背景用本地u2net模型，不将缺依赖时的阈值抠图当作完整安装成功。抠图效果仍需逐图检查。

## 运行入口与检查

首次在新电脑使用，要求用户提供包含本技能的迁移包或已安装目录，按迁移包的安装提示词和 `install.ps1` 完成；不能凭空重建未知源文件。检查 `runtime.json` 的 Python、模型和安装报告。文件不存在或验收失败时先修复环境。

PowerShell调用方式，`<技能目录>` 替换为本次实际加载的技能路径：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_bg.ps1" -h
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_bg.ps1" plan --spec "<绝对路径>\job.json"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_bg.ps1" preview --spec "<绝对路径>\job.json" --out "<工作目录>\preview.png" --limit 0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<技能目录>\scripts\run_bg.ps1" batch --spec "<绝对路径>\job.json" --manifest "<工作目录>\files.json"
```

Bypass只用于本次子进程，不更改系统执行策略。也可读取runtime.json，用其中的绝对Python路径运行本技能 `scripts/launch.py` 加同样参数。不要直接用系统 `python` 或 `py` 执行 bg_assets.py。

## PS优先资源设置

本机采用PS优先模式：仍逐张串行；`runtime.json`中`cpu_threads=1`、`process_priority="below_normal"`、`allow_spinning=false`。入口在加载数值库前限制OpenMP、OpenBLAS、MKL、Numba等为1线程，只降低自己的Python进程优先级，不修改PS或系统全局设置。u2net明确使用CPU、串行执行、单线程并关闭推理线程空闲自旋，OpenCV也限为1线程；保持原模型和输出规格，生成时间可能增加。

用`run_bg.ps1 status`核对实际进程优先级和线程环境；需要检查真实推理会话时加`status --load-model`。batch/preview返回JSON的`runtime`记录实际设置，模型未加载时`model_session`为null。自检同样采用这些资源限制，且读取强制实际推理后的会话参数验证。不因测试成功就声称PS一定流畅；卡顿仍需结合当时CPU、内存和磁盘情况判断。用户暂停商品批次时，不因调整参数擅自恢复生成。

## 素材与参数

1. 检查附件或素材目录，数出N并看原图。整版海报、多商品拼图说明抠出的是整版，先明确商品范围。输入图只读，记录输出清单，禁止输出覆盖任何原图。
2. 生成预览前，一轮收集尚缺的信息：保存位置、图片范围、每张图片对应的款号/款名及色名、同色多角度的角度或明确序号，并仅询问一次图片存放方式：A白底图/透明图分文件夹，B两种图片放同一个款式目录。已有明确选择不重复问；款式、颜色、图片对应关系有歧义时集中列出需要确认的项目，不自行猜测。桌面路径用 `[Environment]::GetFolderPath('Desktop')` 获取。
3. A映射`separate_image_folders:true`；B映射`false`，必须使用JSON布尔值，缺失即报错。所有输入和输出根目录用绝对路径；同批统一根目录和目录模式。不要靠文件名推断款式、自动丢弃同色图或用旧`name`任务单绕过必填映射。
4. `plan`在写入前检查Windows非法/保留名称、结尾点或空格、大小写不敏感的重复名和已有目标。冲突时整批停止，不自动覆盖；请用户选择改名或新目录后重新预览。脚本没有强制覆盖开关。默认不主动问尺寸或主体占比。
5. 展示原图→款式→颜色/角度→图片文件名的对应关系、每款两份PSD、目录结构和`2N+2K`预计总数。

任务单用UTF-8无BOM，路径用绝对路径：

```json
{
  "schema_version": 2,
  "defaults": {"out_dir": "D:/商品/本批输出", "separate_image_folders": true},
  "jobs": [
    {"style": "款式A", "color": "蓝色", "input": "D:/素材/蓝色.png"},
    {"style": "款式A", "color": "紫色", "input": "D:/素材/紫色.png"},
    {"style": "款式B", "color": "蓝色", "angle": "正面", "input": "D:/素材/另一款正面.png"},
    {"style": "款式B", "color": "蓝色", "angle": "侧面", "input": "D:/素材/另一款侧面.png"}
  ]
}
```

用户指定占比时在defaults中加 `"fill":0.7`，不指定沿用0.80。复杂背景可明确指定 `"cutout":"rembg"`，要求直接报错而不是降级。需要处理已有透明通道时使用默认auto。

A模式：`输出/款式A/白底图/蓝色.jpg`、`输出/款式A/透明图/蓝色.png`；B模式：`输出/款式A/蓝色-白底.jpg`、`输出/款式A/蓝色-透明.png`。两种模式的PSD位置均为`输出/款式A/款式A-白底.psd`、`输出/款式A/款式A-透明.psd`。选项仅影响图片位置。

返回JSON为批次对象，含`input_count/style_count/image_count/psd_count/total_files`、每款`styles`、全部`outputs`和带款式/图层/原图对应的`files`清单；不再返回逐张四文件数组。单图`make`也必须显式指定`--style`、`--color`和`--separate-image-folders`或`--same-image-folder`，同样使用款式子目录。

## 预览确认与正式生成

1. 必须先生成预览，一行一张，左白底、右透明棋盘格，标注款式和颜色/角度。小批用`--limit 0`展示全部；大批用`--offset`和`--limit`分页，逐页提供预览，不因默认前4张漏掉其余映射。JSON含shown/remaining及完整文件计划。自行查看主体完整性、边缘、背景残留、居中和文案水印；预览不生成正式文件。
2. 展示预览，同时询问效果（确认/占比小7%/大7%/自定义）和PS选项（不用PS/后续排队精修/现在用PS/指定图片）。存在明显抠图问题时点明图号及问题。
3. 展示全部映射、输出结构及预计数量后，用户确认才batch。未确认效果时调整后使用新预览文件名重新预览。仅在用户确认的任务单上生成；测试副本的独立自检素材可按用户验收授权直接测试。
4. 核对2N张图片、2K份PSD和清单。图片/PSD均800×800，JPG角点白色，PNG有有效透明alpha；重新打开每款PSD核对图层名称、位置及默认可见性，逐层切换对比对应PNG和透明合成。脚本在暂存目录生成全部文件后排他写入正式目录；PSD失败返回非零、保留现场，不转队列冒充成功。发生中途写入异常也不得报告完整完成。
5. 交付文件对应关系、总数、检查结果及仍需人工精修的图片。自动验收不保证每张商品都达到人工修图的边缘质量。

## 更新后自检

用runtime.json中的专用Python执行`scripts/selftest.py --skill <技能目录> --work <全新测试目录>`。只使用独立合成测试素材，覆盖两种目录模式下1款3色8文件、2款2+3色14文件；同色多角度及70%占比；PSD重新打开、逐层切换、默认可见性、透明合成、图片白底/alpha/居中、清单计数、预览零正式文件、Windows冲突/已有文件、源图哈希、PSD失败和队列/空闲。还须完成强制本地u2net CPU推理与上游MD5校验。报告passed=true且model_inference=true才算完整通过。

## 可选Photoshop精修

背景处理和分层PSD不需要安装Photoshop。用户明确选择精修时，检查Photoshop已安装、用户可使用且存在可调用的Photoshop工具；缺少连接时如实说明，不能声称已配置或已精修。安装本技能不授权自动安装收费软件、登录账号或连接未知服务。

可用 `queue --file <工作目录>/ps_queue.jsonl --task <JSON>` 记录用户要求，不占用PS。只有用户已选择PS流程并明确同意立即操作，或同意空闲时执行且 `idle` 返回≥600秒，才执行队列；执行前用户恢复操作（idle<60）就停下。每个任务按绝对路径打开→处理→另存→关闭自己的文档，禁止使用activeDocument代指目标，禁止关闭或修改用户其他文档。设置 `app.displayDialogs=DialogModes.NO`，记录done/failed及原因。
